﻿using System;
using System.Globalization;
using System.IO;

using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

namespace Montanari.Giorgia._4H.ElencoFilm
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FinEdit : ContentPage
    {
        Films ArchivioDeiFilm { get; set; }
        public string IG { get; set; }
        public FinEdit()
        {
           
            InitializeComponent();
        }

        private void Save_Clicked(object sender, EventArgs e)
        {
            
            

        }

       public FinEdit(Film f )
            : this()
       {
            
            BindingContext = f;
       }

        private async void ImmGen_Clicked(object sender, EventArgs e)
        {
            IG = await DisplayActionSheet("Scegli l'immagine per identificare il film", "Annulla", "", "Azione", "Romantico", "Horror");
        }

        public void IGEN()
        {
            if (IG == "Azione")
            {
                ArchivioDeiFilm.Add(new Film { Immagine = "Azione.png" });
            }
            else if(IG == "Romantico")
            {
                ArchivioDeiFilm.Add(new Film { Immagine = "Romantico.png" });
            }
            else if(IG == "Horror")
            {
                ArchivioDeiFilm.Add(new Film { Immagine = "Horror.png" });
            }

        }
    }
}