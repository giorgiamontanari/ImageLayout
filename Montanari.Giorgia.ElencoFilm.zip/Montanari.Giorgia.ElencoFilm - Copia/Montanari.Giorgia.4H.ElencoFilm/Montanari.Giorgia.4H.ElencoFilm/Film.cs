﻿using System;
using System.Collections.ObjectModel;
using System.IO;

namespace Montanari.Giorgia._4H.ElencoFilm
{
    public class Film
    {
        public string Immagine { get; set; }
        public string Titolo { get; set; }
        public string Link { get; set; }

       
    }

    public class Films : ObservableCollection<Film>
    {
        public Films()
        {
            Add(new Film { Titolo = "Parasite", Immagine = "https://i.ytimg.com/vi/SEUXfv87Wpk/maxresdefault.jpg", Link = "https://www.youtube.com/watch?v=isOGD_7hNIY" });
            Add(new Film { Titolo = "Train to Busan", Immagine = "https://upload.wikimedia.org/wikipedia/en/9/95/Train_to_Busan.jpg", Link = "https://www.youtube.com/watch?v=pyWuHv2-Abk" });
            Add(new Film { Titolo = "Goksung", Immagine = "https://www.ilcineocchio.it/cine/wp-content/uploads/2016/11/The-Wailng-poster.jpg", Link = "https://www.youtube.com/watch?v=4Um0_tdqeP8&list=PLMStqG7_6tF8IZrFf_uG3KBHp6LAwmON0&index=46" });
        }

        public void Load()
        {
            try
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string fileName = Path.Combine(path, "films.csv");

                if (File.Exists(fileName))
                {
                    StreamReader sr = new StreamReader(fileName);
                    while (!sr.EndOfStream)
                    {
                        string riga = sr.ReadLine();
                        string[] colonne = riga.Split(';');
                        Film f = new Film { Titolo = colonne[0], Immagine = colonne[1], Link = colonne[2] };
                        Add(f);
                    }
                    sr.Close();
                }
            }
            catch (Exception errore) { }

        }
        public void Save()
        {
            try
            {
                string path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string fileName = Path.Combine(path, "films.csv");

                StreamWriter sw = new StreamWriter(fileName);

                foreach (Film f in this)
                {
                    sw.WriteLine($"{f.Titolo};{f.Immagine};{f.Link}");
                }
                sw.Close();
            }
            catch (Exception errore) { }

        }

      

    }
}
