﻿using System;
using System.ComponentModel;
using System.Linq;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace Montanari.Giorgia._4H.ElencoFilm
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    
    public partial class MainPage : ContentPage
    {
        
        Films ArchivioDeiFilm { get; set; }
        public int i { get; set; }
        public MainPage()
        {
            InitializeComponent();

            ArchivioDeiFilm = new Films();
            ArchivioDeiFilm.Load();
            lvDati.ItemsSource = ArchivioDeiFilm;
            
        }

        async private void btnOpenVideo(object sender, EventArgs e)
        {
            // Il record corrente passato con . , è dentro all'attributo "CommandParameter"
            // il quale è dentro al Button...
            // Button ci arriva come object e va fatto un cast con l'operatore as
            // Se l'operatore as torna null, qualcosa è andato storto... meglio non fare nulla
            Button m = sender as Button;
            if (m != null)
            {
                // Anche CommandParameter è un object e serve un cast a Film
                Film f = m.CommandParameter as Film;
                if (f != null)
                {
                    await Browser.OpenAsync(f.Link, BrowserLaunchMode.SystemPreferred);
                }
            }
        }
        private void BtnAdd_Clicked(object sender, EventArgs e)
        {

            ArchivioDeiFilm.Add(new Film { Titolo = "Giorgia", Link = "Http://www.youtube.com", Immagine = "" });

        }

        private void BtnEdit_Clicked(object sender, EventArgs e)
        {

           var f= lvDati.SelectedItem as Film;
            if(f != null)
            {
                Navigation.PushAsync(new FinEdit(f));
            }
           
            

        }

        private void BtnDelete_Clicked(object sender, EventArgs e)
        {
            if (ArchivioDeiFilm.Count() != 0)
            {
                ArchivioDeiFilm.RemoveAt(i);
                lvDati.ItemsSource = null;
                lvDati.ItemsSource = ArchivioDeiFilm;
            }
        }
        
        private void BtnSave_Clicked(object sender, EventArgs e)
        {
            ArchivioDeiFilm.Save();
        }

        
        public void lvDati_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            i = (lvDati.ItemsSource as System.Collections.ObjectModel.ObservableCollection<Film>).IndexOf(e.Item as Film);
        }
    }
}
